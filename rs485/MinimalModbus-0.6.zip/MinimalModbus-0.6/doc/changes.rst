.. _changes:

Changes in MinimalModbus
========================

.. include:: ../CHANGES.txt
