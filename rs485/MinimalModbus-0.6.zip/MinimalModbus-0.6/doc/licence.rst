Licence for MinimalModbus
=========================

.. include:: ../LICENCE.txt
